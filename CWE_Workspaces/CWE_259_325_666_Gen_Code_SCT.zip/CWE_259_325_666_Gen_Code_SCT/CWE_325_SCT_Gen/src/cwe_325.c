
#include "cwe_325.h"

#pragma comment(lib, "advapi32")
			
#define HASH_INPUT "ABCDEFG123456" /* INCIDENTAL: Hardcoded crypto */
#define PAYLOAD "plaintext"


//extern void _CryptDeriveKey(){}
//extern void _CryptEncrypt(){}
//extern void _CryptCreateHash(){}
//extern void _CryptHashData(){}
//extern void _CryptAcquireContext(){}

void bad_path(){
_CryptAcquireContext();

_CryptHashData();

_CryptDeriveKey();

_CryptEncrypt();
	    
}	 		
     
      
void good_path(){  
_CryptAcquireContext();  

_CryptCreateHash();

_CryptHashData();

_CryptDeriveKey();

_CryptEncrypt();
	    
}	 		
     
int main(int argc, char * argv[])
{
good_path(); 
bad_path(); 
printf("cwe 325 finished...");
 return 0;
}
          
