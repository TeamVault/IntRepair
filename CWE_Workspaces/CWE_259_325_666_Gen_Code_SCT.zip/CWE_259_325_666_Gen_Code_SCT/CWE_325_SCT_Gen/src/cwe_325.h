/*@ @function sink
* @postStep _CryptCreateHash @*/
void _CryptAcquireContext();                 

/*@ @function sink
* @preStep _CryptAcquireContext
* @postStep _CryptHashData @*/
void _CryptCreateHash();  

/*@ @function sink
* @preStep _CryptCreateHash
* @postStep _CryptDeriveKey @*/
void _CryptHashData();   

/*@ @function sink
* @preStep _CryptHashData
* @postStep _CryptEncrypt @*/
void _CryptDeriveKey();                   


/*@ @function sink
* @preStep _CryptDerivekey @*/
void _CryptEncrypt();  
