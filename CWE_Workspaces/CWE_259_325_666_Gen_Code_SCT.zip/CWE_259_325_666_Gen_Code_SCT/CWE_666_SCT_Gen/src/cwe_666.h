/*@ @function sink
* @postStep _listen @*/
void _bind();  
           
/*@ @function sink
* @preStep _bind
* @postStep _accept @*/
void _listen();  
          
/*@ @function sink
* @preStep _listen @*/
void _accept();  





