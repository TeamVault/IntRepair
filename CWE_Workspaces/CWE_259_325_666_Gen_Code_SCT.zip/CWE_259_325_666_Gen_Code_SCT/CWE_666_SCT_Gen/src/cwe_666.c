#include "cwe_666.h"

#pragma comment(lib, "advapi32")
			
#define HASH_INPUT "ABCDEFG123456" /* INCIDENTAL: Hardcoded crypto */
#define PAYLOAD "plaintext"
			
//extern void _accept(){}
//extern void _bind(){}
//extern void _listen(){}


void good_path(){            
	        
_bind();
	    
_listen();
	    
_accept();
	    
}

void bad_path(){   

_listen();

_bind();

_accept();

}

int main(int argc, char * argv[])
{
good_path();
bad_path();

printf("cwe 666 finished...");
 return 0;
}
          
