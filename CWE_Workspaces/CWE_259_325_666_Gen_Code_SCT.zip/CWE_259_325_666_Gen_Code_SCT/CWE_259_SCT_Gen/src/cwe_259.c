//For Adnan, Additional requirements
//the generate annotated variables
//have to be put in each good and
//bad path. Not in the header file
//the function bodies are needed just for dynamically
//running the code. For static analysis we don't need the
//function bodies

//don't model and generate close handle
#import "cwe_259.h"
#pragma comment(lib, "advapi32")
			
#define HASH_INPUT "ABCDEFG123456" /* INCIDENTAL: Hardcoded crypto */
#define PAYLOAD "plaintext"

//extern void _fgets(char *a){}
//extern void _LogonUserA(char *a){}
//extern void _CloseHandle(){}
//extern void _strcpy(char *a, char *b){}

void bad_path(){            

//@ @variable b H
char *b;

//@ @variable a L
char *a;

_strcpy(a, b);
	    
_LogonUserA(a);
	    
}

void good_path(){            

//@ @variable b H
char *b;

//@ @variable a L
char *a;

_fgets(a);
	    
_LogonUserA(a);
	    
}	

	 		
          
int main(int argc, char * argv[])
{
good_path(); 
bad_path(); 
printf("cwe 259 finished...");
return 0;
}
          
