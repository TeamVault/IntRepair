
/*@ @function sink
 * @parameter b H
 * @parameter a L @*/
void _strcpy(char *a, char *b);

/*@ @function sink
 * @parameter a L @*/
void _LogonUserA(char *a);

/*@ @function source
* @parameter a L @*/
void _fgets(char *a);




