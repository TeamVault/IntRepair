
/*++
dummy header file for handling some windows data types
@Author: Paul Munetan
@Date: 15.02.2014
--*/

//Remarks:
//#define is a preprocessor token: the compiler itself will never see it.
//typedef is a compiler token: the preprocessor does not care about it.

typedef  int *HANDLE;

//typedef is not working here
int LOGON32_LOGON_NETWORK = 1;
int LOGON32_PROVIDER_DEFAULT = 2;
int stderr = 3;

int LogonUserA(char *username, char *domain, char password, int LOGON32_LOGON_NETWORK, int LOGON32_PROVIDER_DEFAULT, HANDLE pHandle);
int LogonUserW(char *username, char *domain, char password, int LOGON32_LOGON_NETWORK, int LOGON32_PROVIDER_DEFAULT, HANDLE pHandle);
void CloseHandle(HANDLE pHandle);

/**
 * the implementations are not needed.
 * if the implementations are used then the
 * exec() and getSignature() of LogonUserA will
 * be not called
 */
//int LogonUserA(char *username, char *domain, char password, int LOGON32_LOGON_NETWORK, int LOGON32_PROVIDER_DEFAULT, HANDLE pHandle){
//	 if(1)
//	    {
//	        printf("%s\n", 2);
//	    }
//	return 2;
//}
//
//int LogonUserW(char *username, char *domain, char password, int LOGON32_LOGON_NETWORK, int LOGON32_PROVIDER_DEFAULT, HANDLE pHandle){
//	 return 1;
//}
//
//void CloseHandle(HANDLE pHandle){
//
//}
