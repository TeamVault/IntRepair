/**
 */
package org.xtext.example.mydsl.myDsl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Special Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.example.mydsl.myDsl.MyDslPackage#getSpecialExpression()
 * @model
 * @generated
 */
public interface SpecialExpression extends EObject
{
} // SpecialExpression
