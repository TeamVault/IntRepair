/**
 */
package org.xtext.example.mydsl.myDsl;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ref</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.example.mydsl.myDsl.MyDslPackage#getRef()
 * @model
 * @generated
 */
public interface Ref extends IDSpace
{
} // Ref
